import serial
import ctypes
import pyautogui
import math
import fusion
import time

from time import sleep
import time
from ctypes import *
import pyautogui

def move(x , y):
    dx, dy = pyautogui.position()
    windll.user32.SetCursorPos(dx+x, dy+y)

def recv(serial):
    while True:
        data = serial.read(30)
        if data == '':
            continue
        else:
            break
    return data
ser = serial.Serial("com4",115200,timeout=None)
def fuck():
    dx = 0
    dy = 10
    while True:
        d = recv(ser)
        try:
            if d[0] == 120:
                str1 = d.decode()
                data = {
                    'xacc':ctypes.c_short(int(str1[1:5],16)).value,
                    'yacc':ctypes.c_short(int(str1[6:10],16)).value,
                    'zacc':ctypes.c_short(int(str1[11:15],16)).value,
                    'xgyr':ctypes.c_short(int(str1[16:20],16)).value,
                    'ygyr':ctypes.c_short(int(str1[21:25],16)).value,
                    'zgyr':ctypes.c_short(int(str1[26:30],16)).value
                }
                print(time.time())
                x = data['xgyr'] / 65535 * 4000 / 360
                y = data['ygyr'] / 65535 * 4000 / 360
                z = data['zgyr'] / 65535 * 4000 / 360

                print('x:', x)
                print('y:', y)
                print('z:', z)

                maginitude = math.sqrt(x**2 + y**2 + z**2)
                if maginitude < 0.05:
                    pass
                else:
                    movex =int(x * 150)
                    movey =int(z * 130)

                    move(movex,movey)


        except:
            print(d[0])

def main():

    fuck()

if __name__ == '__main__':
    main()