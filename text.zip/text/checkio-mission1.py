def ch():
    text = "          d     "
    text = text.lower()
    l = []
    while text:
        n1 = len(text)
        ch = text[0]
        if ord(ch) <65 or 91<ord(ch)<97 or ord(ch)>122 :
            text = text.replace(text[0], '')
            continue
        text = text.replace(text[0],'')
        n2 = len(text)
        n = n1-n2
        a = (ch,n)
        l.append(a)
    n = len(l)
    print(l)
    num = l[0][1]
    str = l[0][0]
    for i in range(n):

        if num<l[i-1][1]:
            num = l[i-1][1]
            str = l[i-1][0]
        if num == l[i-1][1]:
            if str>l[i-1][0]:
                num = l[i-1][1]
                str = l[i-1][0]
    return str
str = ch()
print('s',str)