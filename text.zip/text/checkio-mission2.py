

def checkio(data):
    list = data.copy()
    if len(data)==1:
        return []
    while data:
        i = data[0]
        n1 = len(data)
        while i in data:
            data.remove(i)
        n2 = len(data)
        if n1==1:
            continue
        if n1-n2 == 1 :
            list.remove(i)
        if n2 ==1:
            list.remove(data[0])
    data =list
    return data


list = [1]
print(checkio(list))